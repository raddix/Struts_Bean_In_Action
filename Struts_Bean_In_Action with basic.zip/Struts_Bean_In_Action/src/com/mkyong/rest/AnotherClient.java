package com.mkyong.rest;

public class AnotherClient {

}
