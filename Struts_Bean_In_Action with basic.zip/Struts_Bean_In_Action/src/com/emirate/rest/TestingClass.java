package com.emirate.rest;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

public class TestingClass {
	
	public static void main(String[] args) throws UnsupportedEncodingException {
		String password = "iandi2qnidni2niq2unn19221n3123";
		byte[] b = password.getBytes();
		String s = Base64.getEncoder().encodeToString(b);
		byte[] decodedBytes = Base64.getDecoder().decode(s);
		String decodedPassworgd= new String(decodedBytes, "UTF-8");
		
		System.out.println(b);
		System.out.println(decodedPassworgd);
		
	}

}
