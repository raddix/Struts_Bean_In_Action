package com.tcs.ilp.action;


import com.tcs.ilp.bean.Customer;


public class CustomerAction   {
	
	private Customer custbean;
	
	
	
	public Customer getCustbean() {
		return custbean;
	}



	public void setCustbean(Customer custbean) {
		this.custbean = custbean;
	}



	public String register(){
		
		return "success";
	}
}
