package com.mkyong.rest;

public class Order {
	
    String custmer;
    String address;
    String amount;
	public String getCustmer() {
		return custmer;
	}
	public void setCustmer(String custmer) {
		this.custmer = custmer;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
}
