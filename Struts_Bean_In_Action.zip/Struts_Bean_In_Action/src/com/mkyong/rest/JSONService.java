package com.mkyong.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/json/metallica")
public class JSONService {

	@GET
	@Path("/get")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Track> getTrackInJSON() {
		System.out.println("I am in JSON Service");
		List<Track> list = new ArrayList<>();
		Track track = new Track();
		track.setTrack("Enter Sandman");
		track.setSinger("Metallica");
		
		Track track2 = new Track();
		track2.setSinger("Babulal");
		track2.setTrack("Loda Khada khada");
		list.add(track);
		list.add(track2);
		return list;

	}
}
